var searchData=
[
  ['packet_5fsize_378',['packet_size',['../structas608__params__s.html#ad979b0c8eb2ec5bad49e8732c5d66ade',1,'as608_params_s::packet_size()'],['../structas608__handle__s.html#aaf8e82ad3f27d2e6839acc984ae4155b',1,'as608_handle_s::packet_size()']]]
];
