var searchData=
[
  ['sensor_5ftype_258',['sensor_type',['../structas608__params__s.html#a905494aeeba3e97253b1ce60492e8128',1,'as608_params_s']]],
  ['status_259',['status',['../structas608__params__s.html#a5393c99e246925076b1dfd69a64177ef',1,'as608_params_s::status()'],['../structas608__handle__s.html#ade818037fd6c985038ff29656089758d',1,'as608_handle_s::status()']]],
  ['supply_5fvoltage_5fmax_260',['SUPPLY_VOLTAGE_MAX',['../driver__as608_8c.html#a68eba8b601afe11f1b871d944976c035',1,'driver_as608.c']]],
  ['supply_5fvoltage_5fmax_5fv_261',['supply_voltage_max_v',['../structas608__info__s.html#a3d2b12bcac7a85ea8646bff9debe8660',1,'as608_info_s']]],
  ['supply_5fvoltage_5fmin_262',['SUPPLY_VOLTAGE_MIN',['../driver__as608_8c.html#aac8d8cbd899667d609787ef4cf37054d',1,'driver_as608.c']]],
  ['supply_5fvoltage_5fmin_5fv_263',['supply_voltage_min_v',['../structas608__info__s.html#ad8bde6ddadaf43d951e62f3befb9d35a',1,'as608_info_s']]]
];
