var searchData=
[
  ['fingerprint_5fsize_246',['fingerprint_size',['../structas608__params__s.html#ad3f64da6c71ed1c91024ce498df33346',1,'as608_params_s']]]
];
