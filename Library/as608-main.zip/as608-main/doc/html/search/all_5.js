var searchData=
[
  ['inited_247',['inited',['../structas608__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f',1,'as608_handle_s']]],
  ['interface_248',['interface',['../structas608__info__s.html#aebaa6c28dd4f2c3dc27566fcb910fd28',1,'as608_info_s']]]
];
