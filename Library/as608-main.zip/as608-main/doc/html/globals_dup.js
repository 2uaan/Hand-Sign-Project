var globals_dup =
[
    [ "a", "globals.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "m", "globals_m.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ]
];