var driver__as608__basic_8h =
[
    [ "AS608_BASIC_DEFAULT_ADDRESS", "group__as608__example__driver.html#ga356e98bea5bfc189306f33a420e41e60", null ],
    [ "AS608_BASIC_DEFAULT_BAUD_RATE", "group__as608__example__driver.html#gade69c36ee922881a9c6b10bce2d9d845", null ],
    [ "AS608_BASIC_DEFAULT_FEATURE", "group__as608__example__driver.html#ga70f5e8e5259bc5b4f44416e401b52a86", null ],
    [ "AS608_BASIC_DEFAULT_LEVEL", "group__as608__example__driver.html#ga1e7496ddaf3fe3a95c6b91251c81fd65", null ],
    [ "AS608_BASIC_DEFAULT_PACKET_SIZE", "group__as608__example__driver.html#ga0600ff934e2303014f9517e7f52d1575", null ],
    [ "AS608_BASIC_DEFAULT_PASSWORD", "group__as608__example__driver.html#gad4cb1b2db6c2589f3682a4843ce220d0", null ],
    [ "AS608_BASIC_DEFAULT_PORT", "group__as608__example__driver.html#gaf0ac5a7a0cbc1b8d872f11adcc71f033", null ],
    [ "AS608_BASIC_DEFAULT_TIMEOUT", "group__as608__example__driver.html#gaec2bea333644bd112b86accad2b9f578", null ],
    [ "AS608_BASIC_SEND_CONFIG", "group__as608__example__driver.html#gab3fa6d6d463c170bcf1ae5989a80bc58", null ],
    [ "as608_basic_deinit", "group__as608__example__driver.html#gab3150eafb391496e6d8f386f97707b75", null ],
    [ "as608_basic_delete_fingerprint", "group__as608__example__driver.html#ga61f0a14cc33e85d5dd9f588b5cc0b7c9", null ],
    [ "as608_basic_empty_fingerprint", "group__as608__example__driver.html#ga3f1cc256a810465f4061b474de22de11", null ],
    [ "as608_basic_high_speed_verify", "group__as608__example__driver.html#gae140ae216e01446cbe47c5017814c2b5", null ],
    [ "as608_basic_init", "group__as608__example__driver.html#ga4ee2baabfe4382691ae6a8ad44f7f4aa", null ],
    [ "as608_basic_input_fingerprint", "group__as608__example__driver.html#ga80384acd33761469d9ddec40e2432bd3", null ],
    [ "as608_basic_print_status", "group__as608__example__driver.html#ga7687a2ae418b687eb6d9f1979edcd7bc", null ],
    [ "as608_basic_verify", "group__as608__example__driver.html#gace1d860ba178b790e35222cb46cfa3ec", null ]
];