var structas608__handle__s =
[
    [ "buf", "structas608__handle__s.html#ae5b98bbfc169e49d173d43a7d7cb273c", null ],
    [ "debug_print", "structas608__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b", null ],
    [ "delay_ms", "structas608__handle__s.html#a406c9433252b7366de417b7a60915c81", null ],
    [ "inited", "structas608__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f", null ],
    [ "packet_size", "structas608__handle__s.html#aaf8e82ad3f27d2e6839acc984ae4155b", null ],
    [ "status", "structas608__handle__s.html#ade818037fd6c985038ff29656089758d", null ],
    [ "uart_deinit", "structas608__handle__s.html#a57faa7438fdabb6134dabb8b386707a8", null ],
    [ "uart_flush", "structas608__handle__s.html#a1926b171e2786f52634d78953df6612a", null ],
    [ "uart_init", "structas608__handle__s.html#ad6e221373f53cf56fdeec9c64bbc6423", null ],
    [ "uart_read", "structas608__handle__s.html#a9f6681bb2ac30875d94d016ad0137ab2", null ],
    [ "uart_write", "structas608__handle__s.html#a280c8d239a837172fc2fee6eaec7edff", null ]
];