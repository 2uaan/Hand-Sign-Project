var structas608__params__s =
[
    [ "address", "structas608__params__s.html#ac0d31ca829f934cccd89f8054e02773e", null ],
    [ "fingerprint_size", "structas608__params__s.html#ad3f64da6c71ed1c91024ce498df33346", null ],
    [ "level", "structas608__params__s.html#a57b3ab743677dfa7044f14c0c845f2c2", null ],
    [ "n_9600", "structas608__params__s.html#acd80dac9b4903e6e01250b6f89d081f8", null ],
    [ "packet_size", "structas608__params__s.html#ad979b0c8eb2ec5bad49e8732c5d66ade", null ],
    [ "sensor_type", "structas608__params__s.html#a905494aeeba3e97253b1ce60492e8128", null ],
    [ "status", "structas608__params__s.html#a5393c99e246925076b1dfd69a64177ef", null ]
];