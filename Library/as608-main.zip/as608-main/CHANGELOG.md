## 1.0.4 (2025-01-05)

## Bug Fixes

- fix getopt errors

## 1.0.3 (2024-11-30)

## Bug Fixes

- fix doc errors

## 1.0.2 (2024-08-05)

## Bug Fixes

- fix doc errors

## 1.0.1 (2024-04-15)

## Bug Fixes

- fix doc errors.

## 1.0.0 (2023-09-30)

## Features

- first upload