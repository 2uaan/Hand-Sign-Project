### Instruction

as608_datasheet.pdf is confidential.Please inquire from http://www.synochip.com.
